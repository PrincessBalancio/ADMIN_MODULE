package com.example.ui;

import java.awt.*;
import java.awt.event.*;
import java.time.*;
import java.time.format.TextStyle;
import java.util.Locale;
import javax.swing.*;
import javax.swing.border.*;

public class Calendar_Schedule extends JFrame {

    private JPanel calendarGrid;
    private JLabel calendarTitle;
    private YearMonth currentMonth;

    public Calendar_Schedule() {

        setTitle("Employee Shift Calendar");
        setSize(1100, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        getContentPane().setBackground(Color.WHITE);

        currentMonth = YearMonth.now();

        // ===== TOP HEADER BAR =====
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(new Color(10, 25, 74));
        header.setBorder(new MatteBorder(0, 0, 1, 0, new Color(0, 0, 0)));
        header.setPreferredSize(new Dimension(getWidth(), 60));

        // LEFT HEADER (prev / next)
        JPanel leftHeader = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 12));
        leftHeader.setBackground(new Color(10, 25, 74));

        JButton btnPrevMonth = new JButton("◀");
        JButton btnNextMonth = new JButton("▶");
        stylizeHeaderButton(btnPrevMonth);
        stylizeHeaderButton(btnNextMonth);

        leftHeader.add(btnPrevMonth);
        leftHeader.add(btnNextMonth);
        header.add(leftHeader, BorderLayout.WEST);

        // CENTER HEADER (Title)
        JPanel centerHeader = new JPanel(new FlowLayout(FlowLayout.CENTER, 6, 12));
        centerHeader.setBackground(new Color(10, 25, 74));

        calendarTitle = new JLabel();
        calendarTitle.setFont(new Font("Segoe UI", Font.BOLD, 18));
        calendarTitle.setForeground(Color.WHITE);
        updateCalendarTitle();
        centerHeader.add(calendarTitle);

        header.add(centerHeader, BorderLayout.CENTER);

        // RIGHT HEADER (clock)
        JPanel rightHeader = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 12));
        rightHeader.setBackground(new Color(10, 25, 74));

        JLabel lblClock = new JLabel();
        lblClock.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblClock.setForeground(Color.WHITE);
        rightHeader.add(lblClock);

        header.add(rightHeader, BorderLayout.EAST);
        add(header, BorderLayout.NORTH);

        // BUTTON LISTENERS
        btnPrevMonth.addActionListener(e -> {
            currentMonth = currentMonth.minusMonths(1);
            updateCalendarTitle();
            generateCalendar();
        });
        btnNextMonth.addActionListener(e -> {
            currentMonth = currentMonth.plusMonths(1);
            updateCalendarTitle();
            generateCalendar();
        });

        // LIVE CLOCK TIMER
        javax.swing.Timer timer = new javax.swing.Timer(1000, e -> {
            lblClock.setText(LocalTime.now().format(
                java.time.format.DateTimeFormatter.ofPattern("HH:mm:ss")));
        });
        timer.start();

        // ===== LEFT EMPLOYEE LIST =====
        JPanel leftPanel = new JPanel();
        leftPanel.setPreferredSize(new Dimension(260, getHeight()));
        leftPanel.setBackground(Color.WHITE);
        leftPanel.setLayout(new BorderLayout());
        leftPanel.setBorder(new MatteBorder(0, 0, 0, 1, new Color(220, 220, 220)));

        JLabel leftTitle = new JLabel("Employees");
        leftTitle.setFont(new Font("Segoe UI", Font.BOLD, 18));
        leftTitle.setBorder(new EmptyBorder(15, 15, 15, 5));

        JPanel listContainer = new JPanel();
        listContainer.setLayout(new BoxLayout(listContainer, BoxLayout.Y_AXIS));
        listContainer.setBackground(Color.WHITE);

        // DUMMY EMPLOYEES ON TABLE EXAMPLES-------------
        listContainer.add(makeEmployeeItem("Juan Dela Cruz", "Regular"));
        listContainer.add(makeEmployeeItem("Maria Santos", "Regular"));
        listContainer.add(makeEmployeeItem("Mark Reyes", "Part-Time"));
        listContainer.add(makeEmployeeItem("", ""));  // blank row
        listContainer.add(makeEmployeeItem("", ""));  // blank row
        listContainer.add(makeEmployeeItem("", ""));  // blank row

        JScrollPane scroll = new JScrollPane(listContainer);
        scroll.setBorder(null);

        leftPanel.add(leftTitle, BorderLayout.NORTH);
        leftPanel.add(scroll, BorderLayout.CENTER);
        add(leftPanel, BorderLayout.WEST);

        // ------------ MAIN CALENDAR AREA -------------
        JPanel calendarPanel = new JPanel(new BorderLayout());
        calendarPanel.setBackground(Color.WHITE);
        calendarPanel.setBorder(new EmptyBorder(15, 15, 15, 15));

        calendarGrid = new JPanel(new GridLayout(0, 7, 5, 5));
        calendarGrid.setBackground(Color.WHITE);

        generateCalendar();
        calendarPanel.add(calendarGrid, BorderLayout.CENTER);

        add(calendarPanel, BorderLayout.CENTER);
    }

    private JPanel makeEmployeeItem(String name, String shift) {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(Color.WHITE);
        panel.setBorder(new MatteBorder(0, 0, 1, 0, new Color(230, 230, 230)));
        panel.setPreferredSize(new Dimension(240, 48));  // FIXED ROW HEIGHT

        JLabel lblName = new JLabel(name);
        lblName.setFont(new Font("Segoe UI", Font.BOLD, 14));

        JLabel lblShift = new JLabel(shift);
        lblShift.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblShift.setForeground(Color.GRAY);

        panel.add(lblName);
        panel.add(lblShift);

        return panel;
    }

    private void generateCalendar() {
        calendarGrid.removeAll();

        // WEEKDAY HEADERS
        String[] days = {"Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"};
        for (String d : days) {
            JLabel label = new JLabel(d, SwingConstants.CENTER);
            label.setFont(new Font("Segoe UI", Font.BOLD, 14));
            label.setBorder(new MatteBorder(0, 0, 1, 0, new Color(200, 200, 200)));
            label.setOpaque(true);
            label.setBackground(new Color(250, 250, 250));
            calendarGrid.add(label);
        }

        YearMonth ym = currentMonth;
        int daysInMonth = ym.lengthOfMonth();
        LocalDate first = ym.atDay(1);
        int startOffset = (first.getDayOfWeek().getValue() + 6) % 7;

        for (int i = 0; i < startOffset; i++) {
            JPanel blank = new JPanel();
            blank.setBackground(Color.WHITE);
            blank.setBorder(new MatteBorder(1, 1, 1, 1, new Color(230, 230, 230)));
            calendarGrid.add(blank);
        }

        LocalDate today = LocalDate.now();

        for (int day = 1; day <= daysInMonth; day++) {
            LocalDate date = ym.atDay(day);

            JPanel dayPanel = new JPanel();
            dayPanel.setLayout(new BorderLayout());
            dayPanel.setBorder(new MatteBorder(1, 1, 1, 1, new Color(230, 230, 230)));
            dayPanel.setBackground(Color.WHITE);

            JPanel dateTop = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 6));
            dateTop.setOpaque(false);

            JLabel lblDay = new JLabel(String.valueOf(day));
            lblDay.setFont(new Font("Segoe UI", Font.PLAIN, 13));

            // HIGHLIGHT CURRENT DAY
            if (date.equals(today)) {
                lblDay.setForeground(Color.WHITE);
                lblDay.setOpaque(true);
                lblDay.setBackground(new Color(0x4A90E2));
                lblDay.setHorizontalAlignment(SwingConstants.CENTER);
                lblDay.setPreferredSize(new Dimension(32, 32));
                lblDay.setBorder(new LineBorder(new Color(0x4A90E2), 2, true));
            }

            dateTop.add(lblDay);
            dayPanel.add(dateTop, BorderLayout.NORTH);

            calendarGrid.add(dayPanel);
        }

        int totalCells = startOffset + daysInMonth;
        int trailing = (7 - (totalCells % 7)) % 7;

        for (int i = 0; i < trailing; i++) {
            JPanel blank = new JPanel();
            blank.setBackground(Color.WHITE);
            blank.setBorder(new MatteBorder(1, 1, 1, 1, new Color(230, 230, 230)));
            calendarGrid.add(blank);
        }

        calendarGrid.revalidate();
        calendarGrid.repaint();
    }

    private void stylizeHeaderButton(JButton btn) {
        btn.setFocusPainted(false);
        btn.setBorder(new EmptyBorder(8, 12, 8, 12));
        btn.setBackground(new Color(20, 40, 90));
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btn.setBackground(new Color(50, 80, 150));
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn.setBackground(new Color(20, 40, 90));
            }
        });
    }

    private void updateCalendarTitle() {
        calendarTitle.setText("Employee Shift Schedule - "
                + currentMonth.getMonth().getDisplayName(TextStyle.FULL, Locale.ENGLISH)
                + " " + currentMonth.getYear());
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Calendar_Schedule cs = new Calendar_Schedule();
            cs.setVisible(true);
        });
    }
}
