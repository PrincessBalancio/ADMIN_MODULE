package com.example.ui;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.event.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Employee_TimeDashboard extends JFrame {

    private int totalHours = 40;
    private int lateCount = 2;
    private int absenceCount = 3;

    private CircularCard cardTotal, cardLate, cardAbs;
    private JScrollPane scroll;

    private JLabel lblClock, lblDayDate;

    public Employee_TimeDashboard() {
        setTitle("Employee Time Dashboard");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setLayout(new BorderLayout());
        getContentPane().setBackground(Color.WHITE);

       
        // SIDEBAR---------------------
        
        JPanel sidebar = new JPanel(null);
        sidebar.setPreferredSize(new Dimension(220, 0));
        sidebar.setBackground(new Color(43, 64, 99));
        getContentPane().add(sidebar, BorderLayout.WEST);

        // Sidebar buttons----------------------
        int gap = 20; // vertical gap between buttons
        int startY = 50; // starting y-position
        JButton btnAttendance = createSidebarButton("Attendance Management", startY);
        JButton btnCalendar = createSidebarButton("Calendar Schedule", startY + 55); // 45px height + 10px gap
        sidebar.add(btnAttendance);
        sidebar.add(btnCalendar);

        // Back button at the bottom
        JButton btnBack = createSidebarButton("Back", 0); // y set dynamically
        sidebar.add(btnBack);
        sidebar.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                int sidebarHeight = sidebar.getHeight();
                btnBack.setBounds(20, sidebarHeight - 60, 180, 45); // match button height
            }
        });

        // -----------------------
        // MAIN PANEL
        // -----------------------
        JPanel mainPanel = new JPanel(null);
        mainPanel.setBackground(Color.WHITE);
        getContentPane().add(mainPanel, BorderLayout.CENTER);

        // HEADER
        JLabel lblHello = new JLabel("Hello Admin,");
        lblHello.setFont(new Font("Segoe UI", Font.BOLD, 28));
        lblHello.setBounds(20, 20, 500, 40);
        mainPanel.add(lblHello);

        JLabel lblWelcome = new JLabel("Welcome to your Employee Attendance Dashboard");
        lblWelcome.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblWelcome.setBounds(20, 65, 700, 20);
        mainPanel.add(lblWelcome);

        // CLOCK AND DAY/DATE
        lblClock = new JLabel();
        lblClock.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        mainPanel.add(lblClock);

        lblDayDate = new JLabel();
        lblDayDate.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        mainPanel.add(lblDayDate);

        Timer timer = new Timer(1000, e -> updateClock());
        timer.start();

        
        // CARDS----------
       
        cardTotal = new CircularCard("Total Hours Worked", totalHours, 100, new Color(135, 206, 250));
        cardLate = new CircularCard("Number of Late Resumptions", lateCount * 10, 100, new Color(135, 206, 250));
        cardAbs = new CircularCard("Number of Absences", absenceCount * 10, 100, new Color(135, 206, 250));

        mainPanel.add(cardTotal);
        mainPanel.add(cardLate);
        mainPanel.add(cardAbs);

        SwingUtilities.invokeLater(() -> {
            cardTotal.animate();
            cardLate.animate();
            cardAbs.animate();
        });

        // TABLE TITLE-----------------
        JLabel lblRecord = new JLabel("Attendance Record");
        lblRecord.setFont(new Font("Segoe UI", Font.BOLD, 16));
        mainPanel.add(lblRecord);

        // TABLE DUMMY EMPLOYEE EXAMPLES -----------------------
        String[] colNames = {"Employee ID", "Name", "Date", "Time In", "Time Out", "Status"};
        Object[][] rowData = {
                {"EMP001", "John Cruz", "Nov 20", "8:00 AM", "5:00 PM", "Present"},
                {"EMP001", "John Cruz", "Nov 21", "8:15 AM", "5:03 PM", "Late"},
                {"EMP001", "John Cruz", "Nov 22", "--", "--", "Absent"},
                {"EMP001", "John Cruz", "Nov 23", "8:00 AM", "5:02 PM", "Present"}
        };

        DefaultTableModel model = new DefaultTableModel(rowData, colNames) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };

        JTable attendanceTable = new JTable(model) {
            @Override
            public Component prepareRenderer(TableCellRenderer renderer, int row, int col) {
                Component c = super.prepareRenderer(renderer, row, col);
                if (!isRowSelected(row)) {
                    c.setBackground(row % 2 == 0 ? new Color(245, 248, 255) : Color.WHITE);
                } else {
                    c.setBackground(new Color(173, 216, 230));
                }
                if (c instanceof JComponent) ((JComponent)c).setBorder(BorderFactory.createEmptyBorder(8,10,8,10));
                return c;
            }
        };

        attendanceTable.setRowHeight(38);
        attendanceTable.setShowHorizontalLines(false);
        attendanceTable.setShowVerticalLines(false);
        attendanceTable.setIntercellSpacing(new Dimension(0,0));
        attendanceTable.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        attendanceTable.setSelectionForeground(Color.BLACK);

        JTableHeader header = attendanceTable.getTableHeader();
        header.setPreferredSize(new Dimension(0,40));
        header.setFont(new Font("Segoe UI", Font.BOLD, 15));
        header.setOpaque(true);
        header.setBackground(new Color(220, 230, 245));
        header.setBorder(new MatteBorder(0,0,2,0,new Color(200,210,230)));

        scroll = new JScrollPane(attendanceTable);
        scroll.setBorder(new LineBorder(new Color(210,210,210),2,true));
        scroll.getViewport().setBackground(Color.WHITE);
        JScrollBar vsb = scroll.getVerticalScrollBar();
        vsb.setUnitIncrement(16);
        mainPanel.add(scroll);

        // -----------------------
        // RESIZE HANDLER
        // -----------------------
        mainPanel.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                resizeComponents(mainPanel, lblRecord);
            }
        });
    }

    private void updateClock() {
        Date now = new Date();
        lblClock.setText(new SimpleDateFormat("hh:mm:ss a").format(now));
        lblDayDate.setText(new SimpleDateFormat("EEEE, MMM dd yyyy").format(now));
    }

    private void resizeComponents(JPanel mainPanel, JLabel lblRecord) {
        int width = mainPanel.getWidth() - 40; // padding
        int gap = 20;
        int cardWidth = (width - 2 * gap) / 3;
        int cardHeight = 180;

        cardTotal.setBounds(20, 110, cardWidth, cardHeight);
        cardLate.setBounds(20 + cardWidth + gap, 110, cardWidth, cardHeight);
        cardAbs.setBounds(20 + (cardWidth + gap) * 2, 110, cardWidth, cardHeight);

        lblRecord.setBounds(20, 310, width, 30);
        scroll.setBounds(20, 350, width, mainPanel.getHeight() - 370);

        // Clock on the top right
        lblClock.setBounds(width - 180, 20, 160, 20);
        lblDayDate.setBounds(width - 180, 45, 160, 20);
    }

    class CircularCard extends JPanel {
        private int value;
        private int maxValue;
        private int currentValue = 0;
        private Color progressColor;
        private JLabel lblTitle;

        public CircularCard(String title, int value, int maxValue, Color progressColor) {
            this.value = value;
            this.maxValue = maxValue;
            this.progressColor = progressColor;
            setLayout(null);
            setBackground(Color.WHITE);
            setBorder(new MatteBorder(1,1,1,1,new Color(220,220,220)));

            lblTitle = new JLabel(title);
            lblTitle.setFont(new Font("Segoe UI", Font.PLAIN, 14));
            lblTitle.setBounds(10, 10, 280, 20);
            add(lblTitle);
        }

        public void animate() {
            Timer t = new Timer(12, null);
            t.addActionListener(e -> {
                if (currentValue < value) {
                    currentValue++;
                    repaint();
                } else {
                    ((Timer)e.getSource()).stop();
                }
            });
            t.start();
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            int padding = Math.max(20, getWidth() / 10);
            int size = Math.min(getWidth(), getHeight()) - padding * 2;
            size = Math.max(size, 50);
            int x = (getWidth() - size) / 2;
            int y = (getHeight() - size) / 2;

            g2.setStroke(new BasicStroke(size / 10f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            g2.setColor(new Color(230, 230, 230));
            g2.drawOval(x, y, size, size);

            float ratio = Math.min(1f, (float) currentValue / Math.max(1, maxValue));
            int angle = (int)(360f * ratio);
            g2.setColor(progressColor);
            g2.drawArc(x, y, size, size, 90, -angle);

            String vtext = currentValue + "%";
            g2.setFont(new Font("Segoe UI", Font.BOLD, size / 4));
            g2.setColor(Color.BLACK);
            FontMetrics fm = g2.getFontMetrics();
            int tx = x + size/2 - fm.stringWidth(vtext)/2;
            int ty = y + size/2 + fm.getAscent()/2;
            g2.drawString(vtext, tx, ty);
        }
    }

    private JButton createSidebarButton(String text, int yPos) {
        JButton btn = new JButton(text);
        btn.setBounds(20, yPos, 180, 45); // uniform height
        btn.setFocusPainted(false);
        btn.setForeground(Color.WHITE);
        btn.setBackground(new Color(43, 64, 99));
        btn.setFont(new Font("Segoe UI", Font.BOLD, 15)); // bold for readability
        btn.setBorderPainted(false);
        btn.setOpaque(true);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        Color normal = new Color(43, 64, 99);
        Color hover = new Color(60, 90, 130);

        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e){ btn.setBackground(hover); }
            public void mouseExited(MouseEvent e){ btn.setBackground(normal); }
        });

        return btn;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Employee_TimeDashboard().setVisible(true));
    }
}
