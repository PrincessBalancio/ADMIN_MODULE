package com.example.ui;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.time.*;
import java.time.format.*;
import java.util.Locale;

public class Attendance_Management extends JFrame {

    private JPanel content;
    private JScrollPane scrollPane;
    private JPanel monthPanel;
    private JPanel cardPanel; // CardLayout panel
    private CardLayout cardLayout;
    private int year;
    private JLabel clockLabel;

    public Attendance_Management() {
        setTitle("Attendance Tracking and Management");
        setSize(1400, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        year = LocalDate.now().getYear();

        // Main layout
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(Color.WHITE);
        getContentPane().add(mainPanel);

        // ---------------- TOP BAR ----------------
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setBackground(new Color(45, 55, 90));
        topBar.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20)); // Reduced vertical padding
        mainPanel.add(topBar, BorderLayout.NORTH);

        JLabel titleLabel = new JLabel("Attendance Tracking and Management");
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setFont(new Font("Poppins", Font.BOLD, 20));
        topBar.add(titleLabel, BorderLayout.WEST);

        JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 0));
        rightPanel.setBackground(new Color(45, 55, 90));

        clockLabel = new JLabel();
        clockLabel.setFont(new Font("Poppins", Font.PLAIN, 13));
        clockLabel.setForeground(Color.WHITE);
        updateClock();
        Timer timer = new Timer(1000, e -> updateClock());
        timer.start();
        rightPanel.add(clockLabel);

        topBar.add(rightPanel, BorderLayout.EAST);

        // ---------------- CARD PANEL ----------------
        cardLayout = new CardLayout();
        cardPanel = new JPanel(cardLayout);

        // Panel for Attendance Table + Back Button
        JPanel attendancePanel = new JPanel();
        attendancePanel.setLayout(new BorderLayout(0, 0)); // No vertical gap
        attendancePanel.setBackground(Color.WHITE);

        // Back Button
        JPanel backPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5)); // Reduced gaps
        backPanel.setBackground(Color.WHITE);
        JButton backButton = new JButton("BACK");
        backButton.setFont(new Font("Poppins", Font.BOLD, 13));
        backButton.setBackground(new Color(200, 200, 200));
        backButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        backButton.setFocusPainted(false);
        backButton.addActionListener(e -> JOptionPane.showMessageDialog(this, "Back button clicked!"));
        backPanel.add(backButton);

        attendancePanel.add(backPanel, BorderLayout.NORTH);

        // ---------------- CENTER CONTENT ----------------
        content = new JPanel(new GridBagLayout());
        content.setBackground(Color.WHITE);

        scrollPane = new JScrollPane(content);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);

        // Remove extra space above the table
        scrollPane.setViewportBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));

        attendancePanel.add(scrollPane, BorderLayout.CENTER);

        cardPanel.add(attendancePanel, "Attendance");

        mainPanel.add(cardPanel, BorderLayout.CENTER);

        // ---------------- MONTH BAR ----------------
        monthPanel = new JPanel(new GridLayout(1, 12, 5, 5));
        monthPanel.setBackground(Color.WHITE);
        Month currentMonth = Month.NOVEMBER; // Fixed to Nov

        Color babyBlue = new Color(173, 216, 230);

        for (int i = 1; i <= 12; i++) {
            Month m = Month.of(i);
            JButton monthBtn = new JButton(m.getDisplayName(TextStyle.SHORT, Locale.ENGLISH).toUpperCase());
            monthBtn.setFont(new Font("Poppins", Font.BOLD, 12));
            monthBtn.setFocusPainted(false);
            monthBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            monthBtn.setOpaque(true);
            monthBtn.setBorderPainted(false);

            monthBtn.setBackground(m == currentMonth ? babyBlue : new Color(225, 235, 245));
            monthBtn.setForeground(m == currentMonth ? Color.WHITE : Color.DARK_GRAY);

            int monthIndex = i;
            monthBtn.addActionListener(e -> buildTable(monthIndex));

            monthPanel.add(monthBtn);
        }

        JScrollPane monthScroll = new JScrollPane(
                monthPanel,
                JScrollPane.VERTICAL_SCROLLBAR_NEVER,
                JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED
        );
        monthScroll.setBorder(BorderFactory.createEmptyBorder(5,5,5,5));
        monthScroll.getHorizontalScrollBar().setUnitIncrement(15);
        mainPanel.add(monthScroll, BorderLayout.SOUTH);

        // Build November by default
        buildTable(11);

        setVisible(true);
    }

    private void updateClock() {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("EEE, MMM dd yyyy  HH:mm:ss");
        clockLabel.setText(LocalDateTime.now().format(dtf));
    }

    private void buildTable(int month) {
        content.removeAll();
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(0, 0, 0, 0);

        LocalDate today = LocalDate.now();

        // -------------------Employee data DUMMY EXAMPLESS-------------
        String[][] employees = {
                {"Grant Marshall", "EMP001"},
                {"Pena Valdez", "EMP002"},
                {"Jessica Miles", "EMP003"},
                {"Kerri Barber", "EMP004"},
                {"Natasha Gamble", "EMP005"},
                {"White Castaneda", "EMP006"},
                {"Vanessa Ryan", "EMP007"},
                {"Meredith Hendricks", "EMP008"}
        };

        int daysInMonth = YearMonth.of(year, month).lengthOfMonth();

        // -------- HEADER ROW (Dates) --------
        gbc.gridy = 0;
        gbc.gridx = 1;
        for (int d = 1; d <= daysInMonth; d++) {
            LocalDate date = LocalDate.of(year, month, d);
            String dayName = date.getDayOfWeek().getDisplayName(TextStyle.SHORT, Locale.ENGLISH);

            JPanel header = new JPanel(new BorderLayout());
            header.setPreferredSize(new Dimension(55, 50)); // Table size intact
            header.setBackground(new Color(240, 245, 250));
            header.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.LIGHT_GRAY));

            JLabel dateLabel = new JLabel("<html><center>" + d + "<br>" + dayName + "</center></html>", SwingConstants.CENTER);
            dateLabel.setFont(new Font("Poppins", Font.BOLD, 11));
            if (date.equals(today)) dateLabel.setForeground(new Color(200, 50, 50));

            header.add(dateLabel, BorderLayout.CENTER);
            content.add(header, gbc);
            gbc.gridx++;
        }

        // -------- EMPLOYEE ROWS --------
        int row = 1;
        for (String[] emp : employees) {
            gbc.gridy = row;
            gbc.gridx = 0;

            // Employee Name/ID
            JPanel namePanel = new JPanel(new BorderLayout());
            namePanel.setPreferredSize(new Dimension(150, 50)); // Table size intact
            namePanel.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.LIGHT_GRAY));
            namePanel.setBackground(row % 2 == 0 ? new Color(245, 250, 255) : Color.WHITE);

            JLabel nameLabel = new JLabel("<html><b>" + emp[0] + "</b><br><span style='font-size:9px;color:gray;'>ID: " + emp[1] + "</span></html>", SwingConstants.CENTER);
            namePanel.add(nameLabel, BorderLayout.CENTER);
            content.add(namePanel, gbc);

            // Attendance cells
            gbc.gridx = 1;
            for (int d = 1; d <= daysInMonth; d++) {
                JPanel cell = new JPanel(new BorderLayout());
                cell.setPreferredSize(new Dimension(55, 50));
                cell.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.LIGHT_GRAY));

                if (month == 11) { // -----------------------Only November has dummy data---------------------
                    double r = Math.random();
                    String timeInOut;
                    Color bgColor;
                    if (r < 0.7) { bgColor = new Color(198, 239, 206); timeInOut = "9:00 / 5:00"; } // Present
                    else if (r < 0.85) { bgColor = new Color(255, 235, 156); timeInOut = "9:30 / 5:00"; } // Late
                    else { bgColor = new Color(255, 199, 206); timeInOut = "- / -"; } // Absent
                    cell.setBackground(bgColor);

                    JLabel timeLabel = new JLabel("<html><center>" + timeInOut + "</center></html>", SwingConstants.CENTER);
                    timeLabel.setFont(new Font("Poppins", Font.PLAIN, 10));
                    cell.add(timeLabel, BorderLayout.CENTER);

                } else { // Other months empty
                    cell.setBackground(Color.WHITE);
                }

                content.add(cell, gbc);
                gbc.gridx++;
            }
            row++;
        }

        content.revalidate();
        content.repaint();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Attendance_Management());
    }
}
