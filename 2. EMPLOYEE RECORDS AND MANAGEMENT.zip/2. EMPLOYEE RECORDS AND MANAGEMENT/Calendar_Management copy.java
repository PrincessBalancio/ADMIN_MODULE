package com.example.ui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

public class Calendar_Management {

    private int HOUR_START = 9;
    private int HOUR_END = 16;
    private int SLOT_HEIGHT = 60;
    private int DAY_COLUMN_WIDTH = 180;

    private JFrame frame;
    private JLabel dateRangeLabel;
    private JLabel clockLabel;
    private JLayeredPane[] dayPanes = new JLayeredPane[7];
    private javax.swing.Timer clockTimer;
    private JScrollPane timelineScroll;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Calendar_Management().createAndShowUI());
    }

    private void createAndShowUI() {
        frame = new JFrame("Calendar");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1350, 840);
        frame.setLocationRelativeTo(null);
        frame.getContentPane().setLayout(new BorderLayout(8, 8));
        frame.getRootPane().setBorder(new EmptyBorder(8, 8, 8, 8));
        frame.getContentPane().setBackground(new Color(246, 246, 247));

        frame.getContentPane().add(createLeftDashboard(), BorderLayout.WEST);
        frame.getContentPane().add(createTopHeader(), BorderLayout.NORTH);
        frame.getContentPane().add(createTimelineArea(), BorderLayout.CENTER);

        startClock();
        frame.setVisible(true);
    }

    // --------------------  SIDEBAR --------------------
    private JPanel createLeftDashboard() {
        JPanel dash = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(0, 0, new Color(28, 42, 67), 0, getHeight(), new Color(20, 30, 50));
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.dispose();
            }
        };
        dash.setPreferredSize(new Dimension(220, 0));
        dash.setLayout(new BorderLayout());
        dash.setBorder(new EmptyBorder(20, 12, 20, 12));

        // Center legend
        JPanel legendPanel = new JPanel();
        legendPanel.setOpaque(false);
        legendPanel.setLayout(new BoxLayout(legendPanel, BoxLayout.Y_AXIS));
        legendPanel.add(Box.createVerticalGlue());

        JLabel title = new JLabel("STATUS");
        title.setFont(new Font("SansSerif", Font.BOLD, 16));
        title.setForeground(Color.WHITE);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        legendPanel.add(title);
        legendPanel.add(Box.createRigidArea(new Dimension(0, 16)));

        legendPanel.add(createLegendCardModern(new Color(102, 179, 255), "Shift"));
        legendPanel.add(Box.createRigidArea(new Dimension(0, 6)));
        legendPanel.add(createLegendCardModern(new Color(255, 230, 110), "Leave"));
        legendPanel.add(Box.createRigidArea(new Dimension(0, 6)));
        legendPanel.add(createLegendCardModern(new Color(255, 200, 200), "Available"));
        legendPanel.add(Box.createVerticalGlue());
        dash.add(legendPanel, BorderLayout.CENTER);

        // Bottom BACK button
        JButton back = new JButton("BACK");
        back.setFocusPainted(false);
        back.setFont(new Font("SansSerif", Font.BOLD, 16));
        back.setForeground(Color.WHITE);
        back.setBackground(new Color(58, 103, 196));
        back.setCursor(new Cursor(Cursor.HAND_CURSOR));
        back.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
        addHoverEffect(back, new Color(78, 123, 216), new Color(58, 103, 196));
        back.addActionListener(e -> JOptionPane.showMessageDialog(frame,
                "This is a week-view calendar template.", "Help", JOptionPane.INFORMATION_MESSAGE));

        JPanel bottomPanel = new JPanel();
        bottomPanel.setOpaque(false);
        bottomPanel.setLayout(new BorderLayout());
        bottomPanel.add(back, BorderLayout.CENTER);
        bottomPanel.setBorder(new EmptyBorder(12, 0, 12, 0));
        dash.add(bottomPanel, BorderLayout.SOUTH);

        return dash;
    }

    private JPanel createLegendCardModern(Color color, String text) {
        JPanel card = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 6)) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 12, 12);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        card.setBackground(new Color(44, 66, 110));
        card.setMaximumSize(new Dimension(200, 40));
        card.setAlignmentX(Component.CENTER_ALIGNMENT);
        card.setCursor(new Cursor(Cursor.HAND_CURSOR));
        card.setOpaque(false);

        JLabel bullet = new JLabel("■");
        bullet.setForeground(color);
        bullet.setFont(new Font("SansSerif", Font.BOLD, 18));

        JLabel label = new JLabel(text);
        label.setForeground(Color.WHITE);
        label.setFont(new Font("SansSerif", Font.BOLD, 16));

        card.add(bullet);
        card.add(label);

        // Hover effect
        card.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(MouseEvent evt) {
                card.setBackground(new Color(60, 90, 145));
                card.setBorder(BorderFactory.createCompoundBorder(
                        new LineBorder(color, 2, true),
                        new EmptyBorder(4, 4, 4, 4)
                ));
            }

            public void mouseExited(MouseEvent evt) {
                card.setBackground(new Color(44, 66, 110));
                card.setBorder(null);
            }
        });

        return card;
    }

    private void addHoverEffect(JButton btn, Color hover, Color normal) {
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) { btn.setBackground(hover); }
            public void mouseExited(java.awt.event.MouseEvent evt) { btn.setBackground(normal); }
        });
    }

    // -------------------- TOP HEADER --------------------
    private JPanel createTopHeader() {
        JPanel top = new JPanel(new BorderLayout(8, 8)) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                // Same gradient as sidebar
                GradientPaint gp = new GradientPaint(
                        0, 0, new Color(28, 42, 67),
                        0, getHeight(), new Color(20, 30, 50)
                );
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.dispose();
            }
        };
        top.setBorder(new EmptyBorder(12, 12, 12, 12));

        // Left nav
        JPanel nav = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        nav.setOpaque(false);
        JButton prev = new JButton("◀");
        JButton next = new JButton("▶");
        styleHeaderButton(prev);
        styleHeaderButton(next);
        prev.addActionListener(e -> shiftWeek(-1));
        next.addActionListener(e -> shiftWeek(1));
        nav.add(prev);
        nav.add(next);

        // Center date
        dateRangeLabel = new JLabel();
        dateRangeLabel.setFont(new Font("SansSerif", Font.BOLD, 18));
        dateRangeLabel.setForeground(Color.WHITE);
        dateRangeLabel.setHorizontalAlignment(SwingConstants.CENTER);
        updateDateRangeLabel(LocalDate.now());

        // Right cluster
        JPanel rightCluster = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        rightCluster.setOpaque(false);

        JTextField searchField = new JTextField(12);
        searchField.setFont(new Font("SansSerif", Font.PLAIN, 14));
        searchField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 200), 1),
                new EmptyBorder(6, 10, 6, 10)
        ));
        searchField.setBackground(Color.WHITE);

        JButton searchBtn = new JButton("Search");
        styleHeaderButton(searchBtn);
        rightCluster.add(searchField);
        rightCluster.add(searchBtn);

        // Floating Adjust Time button
        JButton settings = new JButton("ADJUST TIME");//-----------WORKING BUTTON TO SET A TIME ON THE CALENDAR----------
        settings.setFont(new Font("SansSerif", Font.BOLD, 14));
        settings.setBackground(new Color(58, 103, 196));
        settings.setForeground(Color.WHITE);
        settings.setFocusPainted(false);
        settings.setBorder(new EmptyBorder(10, 16, 10, 16));
        settings.setCursor(new Cursor(Cursor.HAND_CURSOR));
        addFloatEffect(settings);
        settings.addActionListener(e -> openHoursSettings());
        rightCluster.add(settings);

        // Clock panel
        JPanel clockPanel = new JPanel(new BorderLayout());
        clockPanel.setPreferredSize(new Dimension(120, 40));
        clockPanel.setBackground(new Color(20, 90, 200));
        clockPanel.setBorder(new EmptyBorder(4, 6, 4, 6));

        clockLabel = new JLabel("", SwingConstants.CENTER);
        clockLabel.setForeground(Color.WHITE);
        clockLabel.setFont(new Font("SansSerif", Font.BOLD, 16));
        clockPanel.add(clockLabel, BorderLayout.CENTER);
        rightCluster.add(clockPanel);

        top.add(nav, BorderLayout.WEST);
        top.add(dateRangeLabel, BorderLayout.CENTER);
        top.add(rightCluster, BorderLayout.EAST);

        return top;
    }

    private void styleHeaderButton(JButton btn) {
        btn.setFocusPainted(false);
        btn.setFont(new Font("SansSerif", Font.BOLD, 14));
        btn.setBackground(new Color(200, 200, 200));
        btn.setForeground(Color.DARK_GRAY);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setBorder(BorderFactory.createEmptyBorder(6, 10, 6, 10));
        addHoverEffect(btn, new Color(160, 160, 160), new Color(200, 200, 200));
    }

    private void addFloatEffect(JButton btn) {
        btn.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(new Color(40, 80, 160), 1, true),
                new EmptyBorder(10, 16, 10, 16)
        ));
        btn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btn.setBackground(new Color(78, 123, 216));
                btn.setLocation(btn.getX(), btn.getY() - 2);
                btn.setBorder(BorderFactory.createCompoundBorder(
                        new LineBorder(new Color(120, 160, 255), 2, true),
                        new EmptyBorder(10, 16, 10, 16)
                ));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                btn.setBackground(new Color(58, 103, 196));
                btn.setLocation(btn.getX(), btn.getY() + 2);
                btn.setBorder(BorderFactory.createCompoundBorder(
                        new LineBorder(new Color(40, 80, 160), 1, true),
                        new EmptyBorder(10, 16, 10, 16)
                ));
            }
        });
    }

    // -------------------- TIMELINE --------------------
    private JPanel createTimelineArea() {
        JPanel container = new JPanel(new BorderLayout());
        container.setBackground(new Color(245, 245, 245));
        container.setBorder(new EmptyBorder(6, 6, 6, 6));
        int totalHeight = (HOUR_END - HOUR_START) * SLOT_HEIGHT;

        JPanel daysHeader = new JPanel(new GridLayout(1, 7, 0, 0));
        daysHeader.setOpaque(false);

        for (int i = 0; i < 7; i++) {
            LocalDate base = LocalDate.now().with(DayOfWeek.MONDAY).plusDays(i);
            DayOfWeek d = base.getDayOfWeek();

            JPanel headerCell = new GlassHeaderCell(d);
            headerCell.setLayout(new BorderLayout());

            JLabel dayLabel = new JLabel(d.getDisplayName(java.time.format.TextStyle.SHORT, Locale.ENGLISH), SwingConstants.CENTER);
            dayLabel.setFont(new Font("SansSerif", Font.BOLD, 15));
            dayLabel.setForeground(new Color(40, 40, 40));

            JLabel dateNum = new JLabel(String.valueOf(base.getDayOfMonth()), SwingConstants.CENTER);
            dateNum.setFont(new Font("SansSerif", Font.PLAIN, 14));
            dateNum.setForeground(new Color(100, 100, 100));

            JPanel cellContent = new JPanel(new GridLayout(2, 1));
            cellContent.setOpaque(false);
            cellContent.add(dayLabel);
            cellContent.add(dateNum);

            headerCell.add(cellContent, BorderLayout.CENTER);

            if (base.equals(LocalDate.now())) {
                headerCell.setBackground(new Color(210, 225, 255));
                headerCell.setOpaque(true);
            }

            daysHeader.add(headerCell);
        }

        JPanel daysColumns = new JPanel(new GridLayout(1, 7, 0, 0));
        daysColumns.setOpaque(false);
        for (int d = 0; d < 7; d++) {
            JLayeredPane dayLayer = new JLayeredPane();
            dayLayer.setPreferredSize(new Dimension(DAY_COLUMN_WIDTH, totalHeight));
            dayLayer.setOpaque(false);

            for (int h = 0; h < HOUR_END - HOUR_START; h++) {
                int y = h * SLOT_HEIGHT;
                JPanel slot = new JPanel(null) {
                    @Override
                    protected void paintComponent(Graphics g) {
                        Graphics2D g2 = (Graphics2D) g.create();
                        g2.setColor(getBackground());
                        g2.fillRect(0, 0, getWidth(), getHeight());
                        g2.dispose();
                        super.paintComponent(g);
                    }
                };
                slot.setBounds(0, y, DAY_COLUMN_WIDTH, SLOT_HEIGHT);
                slot.setBackground(Color.WHITE);
                slot.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 1, new Color(210, 210, 210)));

                int displayHour = (HOUR_START + h) % 24;
                JLabel timeLabel = new JLabel(String.format("%02d:00", displayHour));
                timeLabel.setBounds(4, 4, 50, 16);
                timeLabel.setForeground(new Color(80, 80, 80));
                slot.add(timeLabel);

                slot.addMouseListener(new MouseAdapter() {
                    @Override
                    public void mouseEntered(MouseEvent e) { slot.setBackground(new Color(240, 230, 255)); }
                    @Override
                    public void mouseExited(MouseEvent e) { slot.setBackground(Color.WHITE); }
                });

                dayLayer.add(slot, Integer.valueOf(h));
            }

            dayPanes[d] = dayLayer;
            daysColumns.add(dayLayer);
        }

        JPanel row = new JPanel(new BorderLayout());
        row.setOpaque(false);
        row.add(daysColumns, BorderLayout.CENTER);

        JPanel headerAndGrid = new JPanel(new BorderLayout());
        headerAndGrid.setOpaque(false);
        headerAndGrid.add(daysHeader, BorderLayout.NORTH);
        headerAndGrid.add(row, BorderLayout.CENTER);

        timelineScroll = new JScrollPane(headerAndGrid, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        timelineScroll.getViewport().setBackground(Color.WHITE);
        timelineScroll.getVerticalScrollBar().setUnitIncrement(16);
        timelineScroll.setBorder(BorderFactory.createLineBorder(new Color(230, 230, 230)));

        container.add(timelineScroll, BorderLayout.CENTER);
        return container;
    }

    // -------------------- CLOCK & SETTINGS --------------------
    private void startClock() {
        clockTimer = new javax.swing.Timer(1000, e -> clockLabel.setText(
                LocalTime.now().format(DateTimeFormatter.ofPattern("hh:mm a"))
        ));
        clockTimer.start();
    }

    private void openHoursSettings() {
        JPanel p = new JPanel(new GridLayout(0, 2, 6, 6));
        JTextField startFld = new JTextField(String.valueOf(HOUR_START));
        JTextField endFld = new JTextField(String.valueOf(HOUR_END));
        p.add(new JLabel("Start hour (0-23):"));
        p.add(startFld);
        p.add(new JLabel("End hour (1-24):"));
        p.add(endFld);

        int res = JOptionPane.showConfirmDialog(frame, p, "Visible Hours", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (res == JOptionPane.OK_OPTION) {
            try {
                int s = Integer.parseInt(startFld.getText().trim());
                int e = Integer.parseInt(endFld.getText().trim());
                if (s < 0 || s >= e || e > 24) throw new NumberFormatException();
                HOUR_START = s;
                HOUR_END = e;
                frame.getContentPane().remove(2);
                frame.getContentPane().add(createTimelineArea(), BorderLayout.CENTER);
                frame.revalidate();
                frame.repaint();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame, "Invalid hours. Use integers: start < end, 0-24.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void updateDateRangeLabel(LocalDate ref) {
        LocalDate monday = ref.with(DayOfWeek.MONDAY);
        LocalDate sunday = monday.plusDays(6);
        dateRangeLabel.setText("<html><div style='font-size:16px;color:#FFF'>" +
                monday.format(DateTimeFormatter.ofPattern("MMM d")) + " — " +
                sunday.format(DateTimeFormatter.ofPattern("MMM d, yyyy")) +
                "</div></html>");
    }

    private void shiftWeek(int deltaWeeks) {
        LocalDate ref = LocalDate.now().plusWeeks(deltaWeeks);
        updateDateRangeLabel(ref);
    }

    static class GlassHeaderCell extends JPanel {
        GlassHeaderCell(DayOfWeek d) { setOpaque(false); setBorder(new EmptyBorder(8,8,8,8)); }
        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            Color c = new Color(255, 255, 255, 230);
            g2.setColor(c);
            g2.fillRoundRect(4, 4, getWidth()-8, getHeight()-8, 10, 10);
            g2.dispose();
            super.paintComponent(g);
        }
    }
}
