package com.example.ui;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class Admin2_dashboard extends JFrame {

    private static final long serialVersionUID = 1L;
    private JLabel lblClock, lblDay, lblDate;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                Admin2_dashboard frame = new Admin2_dashboard();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public Admin2_dashboard() {
        setTitle("Admin Dashboard");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(90, 90, 1400, 900);

        JPanel contentPane = new JPanel();
        contentPane.setBackground(new Color(245, 247, 250));
        contentPane.setLayout(new BorderLayout(0, 0));
        setContentPane(contentPane);

        // ------------------ SIDEBAR ------------------
        JPanel sidebar = new JPanel();
        sidebar.setBackground(new Color(41, 56, 89));
        sidebar.setPreferredSize(new Dimension(250, 900));
        sidebar.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 0, 10, 0);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;

        JLabel lblDashboard = new JLabel("ADMIN MENU");
        lblDashboard.setForeground(Color.WHITE);
        lblDashboard.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblDashboard.setHorizontalAlignment(SwingConstants.CENTER);
        gbc.gridy = 0;
        sidebar.add(lblDashboard, gbc);

        // Sidebar buttons----------------------------
        String[][] buttons = {
            {"Manual Attendance", "manual", "Manually edit attendance"},
            {"Leave Management", "leave", "Manage leaves"},
            {"Payroll Reports", "reports", "Generate payroll reports"},
            {"System Administration", "system", "System settings & admin"}
        };

        int yPos = 1;
        for (String[] btnInfo : buttons) {
            JButton btn = createSidebarButton(btnInfo[0], btnInfo[1], btnInfo[2]);
            gbc.gridy = yPos++;
            sidebar.add(btn, gbc);
        }

        // Logout button--------------------------------
        JButton btnLogout = new JButton("Logout");
        btnLogout.setFont(new Font("Segoe UI", Font.BOLD, 15));
        btnLogout.setForeground(Color.WHITE);
        btnLogout.setBackground(new Color(220, 53, 69));
        btnLogout.setFocusPainted(false);
        btnLogout.setBorderPainted(false);
        btnLogout.setOpaque(true);
        btnLogout.setPreferredSize(new Dimension(250, 50));
        btnLogout.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btnLogout.setBackground(new Color(200, 35, 50));
            }
            @Override
            public void mouseExited(MouseEvent e) {
                btnLogout.setBackground(new Color(220, 53, 69));
            }
        });
        gbc.gridy = 20;
        sidebar.add(btnLogout, gbc);

        contentPane.add(sidebar, BorderLayout.WEST);

        // ------------------ MAIN PANEL ------------------
        JPanel mainPanel = new JPanel();
        mainPanel.setBackground(new Color(245, 247, 250));
        mainPanel.setLayout(new BorderLayout());

        // --- TOP WHITE HEADER ---
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(Color.WHITE);
        headerPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        headerPanel.setLayout(new BorderLayout());

        // Left: Welcome
        JPanel welcomePanel = new JPanel();
        welcomePanel.setOpaque(false);
        welcomePanel.setLayout(new BoxLayout(welcomePanel, BoxLayout.Y_AXIS));

        JLabel lblTitle = new JLabel("Welcome, Admin!");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 28));
        lblTitle.setForeground(new Color(41, 56, 89));
        welcomePanel.add(lblTitle);

        JLabel lblDesc = new JLabel("Manage your dashboard efficiently.");
        lblDesc.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        lblDesc.setForeground(new Color(41, 56, 89));
        welcomePanel.add(lblDesc);

        headerPanel.add(welcomePanel, BorderLayout.WEST);

        // Right: Clock---------------------------------
        JPanel clockPanel = new JPanel();
        clockPanel.setOpaque(false);
        clockPanel.setLayout(new BoxLayout(clockPanel, BoxLayout.Y_AXIS));
        clockPanel.setAlignmentY(Component.TOP_ALIGNMENT);

        lblClock = new JLabel();
        lblClock.setFont(new Font("DS-Digital", Font.BOLD, 28));
        lblClock.setForeground(new Color(41, 56, 89));
        lblClock.setAlignmentX(Component.RIGHT_ALIGNMENT);
        clockPanel.add(lblClock);

        lblDay = new JLabel();
        lblDay.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        lblDay.setForeground(new Color(41, 56, 89));
        lblDay.setAlignmentX(Component.RIGHT_ALIGNMENT);
        clockPanel.add(lblDay);

        lblDate = new JLabel();
        lblDate.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        lblDate.setForeground(new Color(41, 56, 89));
        lblDate.setAlignmentX(Component.RIGHT_ALIGNMENT);
        clockPanel.add(lblDate);

        headerPanel.add(clockPanel, BorderLayout.EAST);

        mainPanel.add(headerPanel, BorderLayout.NORTH);

        // --- CENTER CARDS PANEL -----------------------
        JPanel cardsPanel = new JPanel();
        cardsPanel.setOpaque(false);
        cardsPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 20));

        int cardSize = 240;
        cardsPanel.add(createCard("Employee Records", "Manage Employee records manually", "manual", 50, cardSize));
        cardsPanel.add(createCard("Leave Management", "Manage leaves efficiently", "leave", 50, cardSize));
        cardsPanel.add(createCard("Payroll Reports", "Generate reports & payslips", "reports", 50, cardSize));

        JPanel centerWrapper = new JPanel(new BorderLayout());
        centerWrapper.setOpaque(false);
        centerWrapper.add(cardsPanel, BorderLayout.NORTH);

        mainPanel.add(centerWrapper, BorderLayout.CENTER);

        contentPane.add(mainPanel, BorderLayout.CENTER);

        startClock();
    }

    // ------------------ SIDEBAR BUTTON ------------------
    private JButton createSidebarButton(String text, String iconType, String tooltip) {
        JButton btn = new JButton(text, new ImageIcon(drawIcon(iconType, 20)));
        btn.setToolTipText(tooltip);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        btn.setForeground(Color.WHITE);
        btn.setBackground(new Color(41, 56, 89));
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setOpaque(true);
        btn.setPreferredSize(new Dimension(250, 50));
        btn.setIconTextGap(10);

        btn.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { btn.setBackground(new Color(55, 75, 120)); }
            @Override public void mouseExited(MouseEvent e) { btn.setBackground(new Color(41, 56, 89)); }
        });

        return btn;
    }

    // ------------------ CREATE CARD WITH BUTTON----------------------------
    private JPanel createCard(String title, String desc, String iconType, int iconSize, int squareSize) {
        final RoundedPanel card = new RoundedPanel(20, Color.WHITE);
        card.setLayout(new BorderLayout());
        card.setBorder(new EmptyBorder(20, 20, 20, 20));
        card.setPreferredSize(new Dimension(squareSize, squareSize));

        // ICON
        JLabel icon = new JLabel(new ImageIcon(drawBlueIcon(iconType, iconSize)));
        icon.setHorizontalAlignment(SwingConstants.CENTER);
        card.add(icon, BorderLayout.NORTH);

        // TITLE
        JLabel lblTitle = new JLabel(title);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblTitle.setForeground(new Color(41, 56, 89));
        lblTitle.setHorizontalAlignment(SwingConstants.CENTER);
        card.add(lblTitle, BorderLayout.CENTER);

        // DESC + BUTTON WRAPPER
        JPanel bottomWrapper = new JPanel(new BorderLayout());
        bottomWrapper.setOpaque(false);

        JLabel lblDesc = new JLabel("<html><center>" + desc + "</center></html>");
        lblDesc.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblDesc.setForeground(new Color(41, 56, 89));
        lblDesc.setHorizontalAlignment(SwingConstants.CENTER);
        bottomWrapper.add(lblDesc, BorderLayout.NORTH);

        // Card-specific button text
        String btnText = "";
        if (title.equals("Employee Records")) btnText = "Open Records";
        else if (title.equals("Leave Management")) btnText = "Open Leaves";
        else if (title.equals("Payroll Reports")) btnText = "Open Reports";

        JButton btnOpen = new JButton(btnText);
        btnOpen.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnOpen.setForeground(Color.WHITE);
        btnOpen.setBackground(new Color(41, 56, 89));
        btnOpen.setFocusPainted(false);
        btnOpen.setBorderPainted(false);
        btnOpen.setPreferredSize(new Dimension(130, 32));
        btnOpen.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        btnOpen.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { btnOpen.setBackground(new Color(55, 75, 120)); }
            @Override public void mouseExited(MouseEvent e) { btnOpen.setBackground(new Color(41, 56, 89)); }
        });

        JPanel btnWrapper = new JPanel();
        btnWrapper.setOpaque(false);
        btnWrapper.add(btnOpen);

        bottomWrapper.add(btnWrapper, BorderLayout.SOUTH);

        card.add(bottomWrapper, BorderLayout.SOUTH);

        // ----------Hover effect for card------------------------------------------
        card.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) {
                card.setLocation(card.getX(), card.getY() - 5);
                card.setBackground(new Color(230, 230, 250));
            }
            @Override public void mouseExited(MouseEvent e) {
                card.setLocation(card.getX(), card.getY() + 5);
                card.setBackground(Color.WHITE);
            }
        });

        return card;
    }

    // ------------------ CLOCK -------------------------------------
    private void startClock() {
        Timer timer = new Timer(1000, e -> {
            Date now = new Date();
            lblClock.setText(new SimpleDateFormat("hh:mm:ss a").format(now));
            lblDay.setText(new SimpleDateFormat("EEEE").format(now));
            lblDate.setText(new SimpleDateFormat("MMMM dd, yyyy").format(now));
        });
        timer.start();
    }

    // ------------------ ICON PLACEHOLDERS ------------------
    private Image drawIcon(String type, int size) {
        BufferedImage img = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = img.createGraphics();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(Color.WHITE);

        int offset = size / 4;
        switch (type) {
            case "manual":
                g2.drawLine(offset / 2, size - offset / 2, size - offset / 2, offset / 2);
                g2.fillRect(size / 4, size - offset, size / 2, size / 10);
                break;
            case "leave":
                g2.fillOval(offset, offset, size / 2, size / 2);
                break;
            case "reports":
                g2.drawRect(offset / 2, offset / 2, size - offset, size - offset);
                g2.drawLine(offset / 2, size / 3, size - offset / 2, size / 3);
                g2.drawLine(offset / 2, size / 2, size - offset / 2, size / 2);
                break;
            case "system":
                g2.drawRoundRect(offset / 2, offset / 2, size - offset, size - offset, 5, 5);
                break;
        }
        g2.dispose();
        return img;
    }
//BLUE ICON-------------------------------------
    private Image drawBlueIcon(String type, int size) {
        BufferedImage img = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = img.createGraphics();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(new Color(41, 56, 89));

        int offset = size / 4;
        switch (type) {
            case "manual":
                g2.drawLine(offset / 2, size - offset / 2, size - offset / 2, offset / 2);
                g2.fillRect(size / 4, size - offset, size / 2, size / 10);
                break;
            case "leave":
                g2.fillOval(offset, offset, size / 2, size / 2);
                break;
            case "reports":
                g2.drawRect(offset / 2, offset / 2, size - offset, size - offset);
                g2.drawLine(offset / 2, size / 3, size - offset / 2, size / 3);
                g2.drawLine(offset / 2, size / 2, size - offset / 2, size / 2);
                break;
        }
        g2.dispose();
        return img;
    }

    // ------------------ ROUNDED PANEL ------------------
    class RoundedPanel extends JPanel {
        private Color backgroundColor;
        private int cornerRadius = 15;

        public RoundedPanel(int radius, Color bgColor) {
            super();
            cornerRadius = radius;
            backgroundColor = bgColor;
            setOpaque(false);
            setLayout(new BorderLayout());
            setBorder(new EmptyBorder(15,15,15,15));
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Dimension arcs = new Dimension(cornerRadius, cornerRadius);
            int width = getWidth();
            int height = getHeight();
            Graphics2D graphics = (Graphics2D) g;
            graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            // Shadow
            graphics.setColor(new Color(0, 0, 0, 50));
            graphics.fillRoundRect(5, 5, width-10, height-10, arcs.width, arcs.height);

            // Background
            graphics.setColor(backgroundColor);
            graphics.fillRoundRect(0, 0, width-10, height-10, arcs.width, arcs.height);
        }
    }
}
