package com.example.ui;

import java.awt.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;
import javax.swing.GroupLayout.Alignment;

public class Archived_Employee extends JFrame {

    private JTable tableEmployees;
    private DefaultTableModel model;

    public Archived_Employee() {

        setTitle("Archived Employee Records");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1100, 650);
        setLocationRelativeTo(null);
        getContentPane().setBackground(new Color(245, 247, 250));

        // COLUMNS -----------------------------------------
        String[] columns = {
            "ID", "Name", "Department", "Position", "Salary",
            "Schedule", "Leave", "Type", "Status"
        };

        model = new DefaultTableModel(columns, 0);

        // EXAMPLE DATA (fixed to match 9 columns) ----------
        Object[][] data = {
            {"001", "rose", "HR", "Manager", "50000", "9-5", "5", "Regular", "Inactive"},
            {"002", "cess", "IT", "Developer", "45000", "9-6", "2", "Part-time", "Inactive"},
            {"003", "pat", "Finance", "Accountant", "47000", "9-5", "3", "Regular", "Inactive"}
        };

        // Add rows
        for (Object[] row : data) {
            model.addRow(row);
        }

        // TABLE -------------------------------------------
        tableEmployees = new JTable(model);
        tableEmployees.setRowHeight(30);
        tableEmployees.setShowGrid(true);
        tableEmployees.setGridColor(new Color(220, 220, 220));
        tableEmployees.setBackground(Color.WHITE);
        tableEmployees.setSelectionBackground(new Color(220, 235, 255));
        tableEmployees.setSelectionForeground(Color.BLACK);
        tableEmployees.setFont(new Font("Segoe UI", Font.PLAIN, 14));

        // HEADER STYLE
        JTableHeader header = tableEmployees.getTableHeader();
        header.setBackground(new Color(50, 90, 160));
        header.setForeground(Color.WHITE);
        header.setFont(new Font("Segoe UI", Font.BOLD, 14));
        header.setReorderingAllowed(false);

        // CUSTOM STATUS BADGE
        tableEmployees.getColumn("Status").setCellRenderer(new StatusBadgeRenderer());

        JScrollPane scroll = new JScrollPane(tableEmployees);
        scroll.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));
        scroll.getViewport().setBackground(Color.WHITE);

        // TOP HEADER PANEL --------------------------------
        JPanel panel = new JPanel();
        panel.setBackground(new Color(40, 65, 120));

        JLabel lblTitle = new JLabel("ARCHIVED EMPLOYEE RECORDS");
        lblTitle.setForeground(Color.WHITE);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 24));

        GroupLayout gl_panel = new GroupLayout(panel);
        gl_panel.setHorizontalGroup(
            gl_panel.createParallelGroup(Alignment.CENTER)
                .addGroup(gl_panel.createSequentialGroup()
                    .addGap(20)
                    .addComponent(lblTitle)
                    .addGap(20))
        );
        gl_panel.setVerticalGroup(
            gl_panel.createParallelGroup(Alignment.CENTER)
                .addGroup(gl_panel.createSequentialGroup()
                    .addGap(10)
                    .addComponent(lblTitle)
                    .addGap(10))
        );
        panel.setLayout(gl_panel);

        // BACK BUTTON WITH HOVER ANIMATION ----------------
        JButton btnBack = new JButton("BACK");
        btnBack.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnBack.setFocusPainted(false);
        btnBack.setBackground(new Color(255, 255, 255));
        btnBack.setForeground(new Color(40, 65, 120));
        btnBack.setBorder(BorderFactory.createLineBorder(new Color(40, 65, 120), 2));

        // Hover animation
        btnBack.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnBack.setBackground(new Color(40, 65, 120));
                btnBack.setForeground(Color.WHITE);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnBack.setBackground(Color.WHITE);
                btnBack.setForeground(new Color(40, 65, 120));
            }
        });

        // BOTTOM PANEL -------------------------------------
        JPanel bottomSpace = new JPanel();
        bottomSpace.setBackground(new Color(235, 240, 250));

        GroupLayout gl_bottom = new GroupLayout(bottomSpace);
        gl_bottom.setHorizontalGroup(
            gl_bottom.createParallelGroup(Alignment.LEADING)
                .addGroup(gl_bottom.createSequentialGroup()
                    .addGap(40)
                    .addComponent(btnBack, GroupLayout.PREFERRED_SIZE, 100, GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(900, Short.MAX_VALUE))
        );
        gl_bottom.setVerticalGroup(
            gl_bottom.createParallelGroup(Alignment.CENTER)
                .addGroup(gl_bottom.createSequentialGroup()
                    .addGap(10)
                    .addComponent(btnBack)
                    .addGap(10))
        );
        bottomSpace.setLayout(gl_bottom);

        // MAIN LAYOUT --------------------------------------
        GroupLayout groupLayout = new GroupLayout(getContentPane());
        groupLayout.setHorizontalGroup(
            groupLayout.createParallelGroup(Alignment.LEADING)
                .addGroup(groupLayout.createSequentialGroup()
                    .addGap(20)
                    .addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
                        .addComponent(panel, GroupLayout.DEFAULT_SIZE, 1060, Short.MAX_VALUE)
                        .addComponent(scroll, GroupLayout.DEFAULT_SIZE, 1060, Short.MAX_VALUE)
                        .addComponent(bottomSpace, GroupLayout.DEFAULT_SIZE, 1060, Short.MAX_VALUE))
                    .addGap(20))
        );
        groupLayout.setVerticalGroup(
            groupLayout.createParallelGroup(Alignment.LEADING)
                .addGroup(groupLayout.createSequentialGroup()
                    .addGap(10)
                    .addComponent(panel, GroupLayout.PREFERRED_SIZE, 60, GroupLayout.PREFERRED_SIZE)
                    .addGap(20)
                    .addComponent(scroll, GroupLayout.PREFERRED_SIZE, 480, GroupLayout.PREFERRED_SIZE)
                    .addGap(10)
                    .addComponent(bottomSpace, GroupLayout.PREFERRED_SIZE, 60, GroupLayout.PREFERRED_SIZE)
                )
        );

        getContentPane().setLayout(groupLayout);
    }

    // STATUS BADGE RENDERER ------------------------------
    class StatusBadgeRenderer extends JLabel implements TableCellRenderer {

        public StatusBadgeRenderer() {
            setOpaque(true);
            setHorizontalAlignment(CENTER);
            setForeground(Color.WHITE);
            setFont(new Font("Segoe UI", Font.BOLD, 12));
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int column) {

            setText(value != null ? value.toString() : "");

            setBackground(new Color(200, 50, 50)); // red badge

            if (isSelected) {
                setBackground(new Color(170, 30, 30));
            }
            return this;
        }
    }

    public static void main(String[] args) {
        new Archived_Employee().setVisible(true);
    }
}
