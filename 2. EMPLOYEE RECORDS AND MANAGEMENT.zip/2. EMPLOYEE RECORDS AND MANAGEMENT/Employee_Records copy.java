package com.example.ui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.table.*;
import javax.swing.GroupLayout.Alignment;

/**
 * Employee_Records (updated with Archive + Calendar buttons + CardLayout)
 */
public class Employee_Records extends JFrame {

    private JTextField txtID, txtName, txtDept, txtPos, txtSalary, txtSchedule, txtLeave;
    private JComboBox<String> cmbType;
    private JTable tableEmployees;
    private DefaultTableModel model;
    private int editingRow = -1;

    private JPanel slidePanel;
    private boolean slideVisible = false;
    private Timer slideTimer;
    private int slideTargetWidth;
    private int slideCurrentWidth = 0;
    private final int SLIDE_STEP = 20;
    private int hoveredRow = -1;

    private CardLayout cardLayout;
    private JPanel cardPanel;

    public Employee_Records() {
        setTitle("Employee Records");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1200, 720);
        setLocationRelativeTo(null);
        getContentPane().setBackground(new Color(249, 253, 255));
        getContentPane().setLayout(new BorderLayout());

        // ====================== HEADER ======================
        JPanel header = new JPanel();
        header.setBackground(new Color(39, 56, 91));
        header.setPreferredSize(new Dimension(0, 64));
        header.setBorder(BorderFactory.createMatteBorder(0,0,1,0,new Color(230,230,230)));

        JLabel headerTitle = new JLabel("Employee Record and Management");
        headerTitle.setForeground(Color.WHITE);
        headerTitle.setFont(new Font("SansSerif", Font.BOLD, 26));
        headerTitle.setBorder(BorderFactory.createEmptyBorder(8, 20, 8, 0));

        JButton btnAdd = new JButton("➕ ADD EMPLOYEE");//----WORKING BUTTON TO ADD EMPLOYEE DETAILS----
        btnAdd.setPreferredSize(new Dimension(150, 38));
        btnAdd.setFocusPainted(false);
        btnAdd.setBackground(new Color(66, 103, 178));
        btnAdd.setForeground(new Color(0, 0, 0));
        btnAdd.setFont(new Font("Serif", Font.PLAIN, 12));
        btnAdd.addActionListener(e -> toggleSlideInForCreate());

        JPanel rightHeader = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 12));
        rightHeader.setOpaque(false);
        rightHeader.add(btnAdd);
        getContentPane().add(header, BorderLayout.NORTH);
        
        JButton btnNewButton = new JButton("BACK");
        btnNewButton.setFont(new Font("PT Serif Caption", Font.PLAIN, 13));
        GroupLayout gl_header = new GroupLayout(header);
        gl_header.setHorizontalGroup(
        	gl_header.createParallelGroup(Alignment.LEADING)
        		.addGroup(gl_header.createSequentialGroup()
        			.addComponent(headerTitle)
        			.addGap(403)
        			.addComponent(btnNewButton)
        			.addGap(18)
        			.addComponent(rightHeader, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
        );
        gl_header.setVerticalGroup(
        	gl_header.createParallelGroup(Alignment.LEADING)
        		.addGroup(gl_header.createParallelGroup(Alignment.BASELINE)
        			.addComponent(headerTitle, GroupLayout.PREFERRED_SIZE, 63, GroupLayout.PREFERRED_SIZE)
        			.addComponent(btnNewButton))
        		.addComponent(rightHeader, GroupLayout.PREFERRED_SIZE, 63, GroupLayout.PREFERRED_SIZE)
        );
        header.setLayout(gl_header);

        // ====================== MAIN AREA ======================
        JPanel main = new JPanel(new BorderLayout());
        main.setBackground(new Color(249,253,255));
        main.setBorder(BorderFactory.createEmptyBorder(12, 18, 18, 18));

        // ====================== TABS BAR + BUTTONS ======================
        JPanel tabs = new JPanel(new BorderLayout());
        tabs.setBackground(new Color(249,253,255));

        JPanel leftTab = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 6));
        leftTab.setOpaque(false);

        JLabel tabEmployees = new JLabel("Employees");
        tabEmployees.setFont(new Font("SansSerif", Font.BOLD, 14));
        tabEmployees.setBorder(BorderFactory.createMatteBorder(0, 0, 3, 0, new Color(66,103,178)));
        leftTab.add(tabEmployees);

        JPanel rightTab = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 6));
        rightTab.setOpaque(false);

        JButton btnArchive = new JButton(" Archived");
        btnArchive.setFocusPainted(false);
        btnArchive.setBackground(new Color(240,240,245));
        btnArchive.setFont(new Font("SansSerif", Font.PLAIN, 20));

        JButton btnCalendar = new JButton(" Calendar");
        btnCalendar.setFocusPainted(false);
        btnCalendar.setBackground(new Color(240,240,245));
        btnCalendar.setFont(new Font("SansSerif", Font.PLAIN, 20));

        rightTab.add(btnArchive);
        rightTab.add(btnCalendar);

        tabs.add(leftTab, BorderLayout.WEST);
        tabs.add(rightTab, BorderLayout.EAST);

        main.add(tabs, BorderLayout.NORTH);

        // ====================== TABLE ======================
        String[] columns = {
            "ID", "Name", "Department", "Position", "Salary",
            "Schedule", "Leave", "Type", "Update", "Delete"
        };

        model = new DefaultTableModel(columns, 0);

        tableEmployees = new JTable(model) {
            public boolean isCellEditable(int row, int col) {
                return col == 8 || col == 9;
            }
        };

        tableEmployees.setRowHeight(68);
        tableEmployees.setShowGrid(false);
        tableEmployees.setIntercellSpacing(new Dimension(0, 0));
        tableEmployees.getTableHeader().setReorderingAllowed(false);
        tableEmployees.getTableHeader().setPreferredSize(new Dimension(0, 42));
        tableEmployees.getTableHeader().setDefaultRenderer(new HeaderRenderer(tableEmployees.getTableHeader().getDefaultRenderer()));
        tableEmployees.setDefaultRenderer(Object.class, new AlternatingRowRenderer());

        TableColumn exportCol = tableEmployees.getColumnModel().getColumn(8);
        exportCol.setCellRenderer(new IconButtonRenderer("⬇️"));
        exportCol.setCellEditor(new IconButtonEditor(new JButton("⬇️")));

        TableColumn editCol = tableEmployees.getColumnModel().getColumn(9);
        editCol.setCellRenderer(new IconButtonRenderer("✏️"));
        editCol.setCellEditor(new IconButtonEditor(new JButton("✏️")));

        JScrollPane scroll = new JScrollPane(tableEmployees);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        scroll.getViewport().setBackground(new Color(249,253,255));

        // ====================== CARDLAYOUT PANELS ======================
        cardLayout = new CardLayout();
        cardPanel = new JPanel(cardLayout);

        JPanel employeesPanel = new JPanel(new BorderLayout());
        employeesPanel.setBackground(new Color(249,253,255));
        employeesPanel.add(scroll, BorderLayout.CENTER);

        JPanel archivedPanel = new JPanel();
        archivedPanel.setBackground(Color.WHITE);
        archivedPanel.add(new JLabel(" Archived Employees"));

        JPanel calendarPanel = new JPanel();
        calendarPanel.setBackground(Color.WHITE);
        calendarPanel.add(new JLabel("Calendar View"));

        cardPanel.add(employeesPanel, "employees");
        cardPanel.add(archivedPanel, "archive");
        cardPanel.add(calendarPanel, "calendar");

        main.add(cardPanel, BorderLayout.CENTER);
        getContentPane().add(main, BorderLayout.CENTER);

        // ====================== BUTTON ACTIONS ======================
        btnArchive.addActionListener(e -> cardLayout.show(cardPanel, "archive"));
        btnCalendar.addActionListener(e -> cardLayout.show(cardPanel, "calendar"));

        tabEmployees.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                cardLayout.show(cardPanel, "employees");
            }
        });

        // ====================== SLIDE PANEL ======================
        slidePanel = new JPanel(new BorderLayout());
        slidePanel.setBackground(new Color(250,250,252));
        slidePanel.setBorder(BorderFactory.createMatteBorder(0,1,0,0,new Color(230,230,230)));
        slidePanel.setPreferredSize(new Dimension(0, getHeight()));

        createSlideFormContents();
        getContentPane().add(slidePanel, BorderLayout.EAST);

        slideTargetWidth = (int) (getWidth() * 0.40);

        addComponentListener(new ComponentAdapter() {
            public void componentResized(ComponentEvent e) {
                slideTargetWidth = (int) (getWidth() * 0.40);
                if (!slideVisible) {
                    slideCurrentWidth = 0;
                    slidePanel.setPreferredSize(new Dimension(0, getHeight()));
                } else {
                    slideCurrentWidth = slideTargetWidth;
                    slidePanel.setPreferredSize(new Dimension(slideCurrentWidth, getHeight()));
                }
                revalidate();
            }
        });

        // Hover effects
        tableEmployees.addMouseMotionListener(new MouseMotionAdapter() {
            public void mouseMoved(MouseEvent e) {
                hoveredRow = tableEmployees.rowAtPoint(e.getPoint());
                tableEmployees.repaint();
            }
        });
        tableEmployees.addMouseListener(new MouseAdapter() {
            public void mouseExited(MouseEvent e) {
                hoveredRow = -1;
                tableEmployees.repaint();
            }
        });

        setVisible(true);
    }

    // =============== HEADER RENDERER ===============
    class HeaderRenderer implements TableCellRenderer {
        private final TableCellRenderer delegate;
        public HeaderRenderer(TableCellRenderer del) { this.delegate = del; }

        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int col) {

            Component c = delegate.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, col);
            c.setBackground(new Color(247,249,251));
            c.setForeground(new Color(80,80,90));
            c.setFont(new Font("SansSerif", Font.BOLD, 13));
            if (c instanceof JLabel) ((JLabel) c).setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
            return c;
        }
    }

    // =============== ROW RENDERER ===============
    class AlternatingRowRenderer extends DefaultTableCellRenderer {
        public Component getTableCellRendererComponent(JTable t, Object v, boolean sel, boolean foc, int row, int col) {
            JLabel lbl = (JLabel) super.getTableCellRendererComponent(t, v, sel, foc, row, col);

            lbl.setBackground(row == hoveredRow ? new Color(240,245,250)
                : row % 2 == 0 ? Color.WHITE
                : new Color(248,250,252));

            lbl.setBorder(BorderFactory.createEmptyBorder(12,14,12,14));
            lbl.setOpaque(true);
            lbl.setFont(new Font("SansSerif", Font.PLAIN, 13));
            return lbl;
        }
    }

    // =============== BUTTON RENDERERS ===============
    class IconButtonRenderer extends JButton implements TableCellRenderer {
        public IconButtonRenderer(String t) {
            setText(t);
            setBorder(BorderFactory.createEmptyBorder(6,10,6,10));
            setBackground(Color.WHITE);
        }

        public Component getTableCellRendererComponent(JTable t, Object v, boolean s, boolean f, int r, int c) {
            setText(c == 8 ? "⬇️" : "✏️");
            return this;
        }
    }

    class IconButtonEditor extends DefaultCellEditor {
        JButton button; int currentRow;
        public IconButtonEditor(JButton btn) {
            super(new JTextField());
            button = new JButton(btn.getText());
            button.setBorder(BorderFactory.createEmptyBorder(6,10,6,10));
            button.setBackground(Color.WHITE);

            button.addActionListener(e -> {
                int col = tableEmployees.getSelectedColumn();
                currentRow = tableEmployees.getSelectedRow();
                if (currentRow < 0) return;

                if (col == 9) {
                    editingRow = currentRow;
                    loadRowToSlide(currentRow);
                } else {
                    JOptionPane.showMessageDialog(Employee_Records.this,
                        "Export for ID: " + model.getValueAt(currentRow, 0));
                }
                fireEditingStopped();
            });
        }

        public Component getTableCellEditorComponent(JTable t, Object v, boolean s, int r, int c) {
            button.setText(c == 8 ? "⬇️" : "✏️");
            return button;
        }
    }

    // -------------- SLIDE PANEL CONTENT -----------
    private void createSlideFormContents() {
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setOpaque(false);
        topBar.setBorder(BorderFactory.createEmptyBorder(12,12,12,12));

        JLabel title = new JLabel("Employee Details");
        title.setFont(new Font("SansSerif", Font.BOLD, 18));

        JButton btnClose = new JButton("✕");
        btnClose.setPreferredSize(new Dimension(40, 32));
        btnClose.setFocusPainted(false);
        btnClose.setBorder(BorderFactory.createEmptyBorder());
        btnClose.setBackground(Color.WHITE);
        btnClose.addActionListener(e -> hideSlidePanel());

        topBar.add(title, BorderLayout.WEST);
        topBar.add(btnClose, BorderLayout.EAST);

        slidePanel.add(topBar, BorderLayout.NORTH);

        JPanel formContainer = new JPanel();
        formContainer.setLayout(new BoxLayout(formContainer, BoxLayout.Y_AXIS));
        formContainer.setBorder(BorderFactory.createEmptyBorder(8,18,18,18));
        formContainer.setOpaque(false);

        formContainer.add(makeGroupPanel("Employee Information",
            "ID", txtID = new JTextField(),
            "Name", txtName = new JTextField()
        ));
        formContainer.add(Box.createRigidArea(new Dimension(0,12)));

        formContainer.add(makeGroupPanel("Job Details",
            "Department", txtDept = new JTextField(),
            "Position", txtPos = new JTextField()
        ));
        formContainer.add(Box.createRigidArea(new Dimension(0,12)));

        formContainer.add(makeGroupPanel("Work Setup",
            "Salary", txtSalary = new JTextField(),
            "Schedule", txtSchedule = new JTextField(),
            "Leave", txtLeave = new JTextField(),
            "Type", cmbType = new JComboBox<>(new String[]{"Regular","Part-time"})
        ));
        formContainer.add(Box.createRigidArea(new Dimension(0,20)));

        JButton btnSave = new JButton("Create"); //---WORKING BUTTON TO CREATE AN EMPLOYEE----
        btnSave.setPreferredSize(new Dimension(160,36));
        btnSave.setBackground(new Color(66,103,178));
        btnSave.setForeground(Color.BLACK);
        btnSave.setFocusPainted(false);
        btnSave.addActionListener(e -> saveData());
        JPanel savePanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        savePanel.setOpaque(false);
        savePanel.add(btnSave);

        formContainer.add(savePanel);

        JScrollPane formScroll = new JScrollPane(formContainer);
        formScroll.setBorder(BorderFactory.createEmptyBorder());
        formScroll.getViewport().setBackground(new Color(250,250,252));

        slidePanel.add(formScroll, BorderLayout.CENTER);
    }

    private JPanel makeGroupPanel(String title, Object... fields) {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setOpaque(false);
        p.setBorder(BorderFactory.createTitledBorder(null, title,
            TitledBorder.LEFT, TitledBorder.TOP));

        for (int i = 0; i < fields.length; i += 2) {
            JLabel lbl = new JLabel(fields[i].toString());
            p.add(lbl);
            p.add(Box.createRigidArea(new Dimension(0,6)));

            Component comp = (Component) fields[i+1];
            comp.setMaximumSize(new Dimension(Integer.MAX_VALUE, 28));
            p.add(comp);
            p.add(Box.createRigidArea(new Dimension(0,10)));
        }
        return p;
    }

    // =============== SAVE LOGIC ===============
    private void saveData() {
        if (editingRow >= 0) {
            model.setValueAt(txtID.getText(), editingRow, 0);
            model.setValueAt(txtName.getText(), editingRow, 1);
            model.setValueAt(txtDept.getText(), editingRow, 2);
            model.setValueAt(txtPos.getText(), editingRow, 3);
            model.setValueAt(txtSalary.getText(), editingRow, 4);
            model.setValueAt(txtSchedule.getText(), editingRow, 5);
            model.setValueAt(txtLeave.getText(), editingRow, 6);
            model.setValueAt(cmbType.getSelectedItem(), editingRow, 7);
            editingRow = -1;
        } else {
            model.addRow(new Object[]{
                txtID.getText(), txtName.getText(), txtDept.getText(), txtPos.getText(),
                txtSalary.getText(), txtSchedule.getText(), txtLeave.getText(),
                cmbType.getSelectedItem(), "Export", "Edit"
            });
        }
        clearFormFields();
        hideSlidePanel();
    }

    private void toggleSlideInForCreate() {
        editingRow = -1;
        clearFormFields();
        showSlidePanel();
    }

    private void loadRowToSlide(int row) {
        txtID.setText(model.getValueAt(row, 0).toString());
        txtName.setText(model.getValueAt(row, 1).toString());
        txtDept.setText(model.getValueAt(row, 2).toString());
        txtPos.setText(model.getValueAt(row, 3).toString());
        txtSalary.setText(model.getValueAt(row, 4).toString());
        txtSchedule.setText(model.getValueAt(row, 5).toString());
        txtLeave.setText(model.getValueAt(row, 6).toString());
        cmbType.setSelectedItem(model.getValueAt(row, 7));
        showSlidePanel();
    }

    private void clearFormFields() {
        txtID.setText("");
        txtName.setText("");
        txtDept.setText("");
        txtPos.setText("");
        txtSalary.setText("");
        txtSchedule.setText("");
        txtLeave.setText("");
        cmbType.setSelectedIndex(0);
    }

    // ------------ SLIDE PANEL-------------
    private void showSlidePanel() {
        if (slideVisible) return;
        slideVisible = true;
        slideTargetWidth = (int) (getWidth() * 0.40);

        slideTimer = new Timer(12, e -> {
            slideCurrentWidth += SLIDE_STEP;
            if (slideCurrentWidth >= slideTargetWidth) {
                slideCurrentWidth = slideTargetWidth;
                slideTimer.stop();
            }
            slidePanel.setPreferredSize(new Dimension(slideCurrentWidth, getHeight()));
            revalidate();
        });
        slideTimer.start();
    }

    private void hideSlidePanel() {
        if (!slideVisible) return;
        slideVisible = false;

        slideTimer = new Timer(12, e -> {
            slideCurrentWidth -= SLIDE_STEP;
            if (slideCurrentWidth <= 0) {
                slideCurrentWidth = 0;
                slideTimer.stop();
            }
            slidePanel.setPreferredSize(new Dimension(Math.max(0, slideCurrentWidth), getHeight()));
            revalidate();
        });
        slideTimer.start();
    }

    // ---------- MAIN ------------
    public static void main(String[] args) {
        try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); } catch (Exception e) {}
        SwingUtilities.invokeLater(Employee_Records::new);
    }
}
