package com.example.ui;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.table.*;

public class Manual_Attendance extends JFrame {

    private JTable tableRequests;
    private JTextPane txtDetails;
    private JPanel bottomPanel;
    private int panelHeight = 0;
    private final int MAX_HEIGHT = 220;
    private Timer slideTimer;

    public Manual_Attendance() {
        // ------------ FRAME SETTINGS ------------
        setTitle("Attendance Requests - Admin Dashboard");
        setSize(1200, 720);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setLayout(new BorderLayout());
        getContentPane().setBackground(Color.WHITE);

        // -------------- TOPBAR -----------------
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setPreferredSize(new Dimension(getWidth(), 60));
        topBar.setBackground(Color.WHITE);
        topBar.setBorder(new MatteBorder(0, 0, 1, 0, new Color(220, 220, 220)));
        getContentPane().add(topBar, BorderLayout.NORTH);

        JLabel lblTitle = new JLabel("Attendance Requests");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblTitle.setBorder(new EmptyBorder(0, 20, 0, 0));
        topBar.add(lblTitle, BorderLayout.WEST);

        JButton btnNotif = new JButton("\uD83D\uDD14");
        btnNotif.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        btnNotif.setFocusPainted(false);
        btnNotif.setBorder(null);
        btnNotif.setContentAreaFilled(false);
        btnNotif.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        topBar.add(btnNotif, BorderLayout.EAST);

        // -------------SIDEBAR -------------
        JPanel sidebar = new JPanel();
        sidebar.setPreferredSize(new Dimension(220, getHeight()));
        sidebar.setBackground(new Color(47, 63, 96));
        sidebar.setLayout(null);
        sidebar.setBorder(new MatteBorder(0, 0, 0, 1, new Color(220, 220, 220)));
        getContentPane().add(sidebar, BorderLayout.WEST);

        JLabel lblMenu = new JLabel("Folders");
        lblMenu.setForeground(Color.WHITE);
        lblMenu.setFont(new Font("Segoe UI", Font.BOLD, 15));
        lblMenu.setBounds(20, 20, 200, 20);
        sidebar.add(lblMenu);

        JButton btnInbox = createSidebarButton("Inbox", true);
        btnInbox.setBounds(10, 55, 200, 35);
        sidebar.add(btnInbox);

        JButton btnApproved = createSidebarButton("Approved", false);
        btnApproved.setBounds(10, 95, 200, 35);
        sidebar.add(btnApproved);

        JButton btnRejected = createSidebarButton("Rejected", false);
        btnRejected.setBounds(10, 135, 200, 35);
        sidebar.add(btnRejected);

        JButton btnArchived = createSidebarButton("Archived", false);
        btnArchived.setBounds(10, 175, 200, 35);
        sidebar.add(btnArchived);

        // ----------MAIN PANEL ---------
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(Color.WHITE);
        getContentPane().add(mainPanel, BorderLayout.CENTER);

        JLabel lblInboxHeader = new JLabel("Inbox");
        lblInboxHeader.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblInboxHeader.setBorder(new EmptyBorder(10, 10, 10, 10));
        mainPanel.add(lblInboxHeader, BorderLayout.NORTH);

        // Table DUMMY EMPLOYEE EXAMPLES------------------------
        String[] columns = { "Employee", "Date", "Correction Type", "Status" };
        Object[][] data = {
            {"Juan Dela Cruz", "2024-06-10", "Clock-in Correction", "Pending"},
            {"Maria Santos", "2024-06-11", "Clock-out Correction", "Pending"},
            {"Mark Reyes", "2024-06-08", "Absent → Present", "Pending"}
        };
        tableRequests = new JTable(data, columns);
        tableRequests.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tableRequests.setRowHeight(30);
        tableRequests.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        tableRequests.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tableRequests.setFillsViewportHeight(true);

        // ===== Table Cell Renderer for Hover & Correction Type =====
        tableRequests.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                    boolean isSelected, boolean hasFocus, int row, int column) {

                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

                // Hover & selection color (baby blue)
                if (isSelected) {
                    c.setBackground(new Color(173, 216, 230)); // baby blue
                } else {
                    c.setBackground(Color.WHITE);
                }

                // Tooltip & color-coding for Correction Type
                if (column == 2 && value != null) {
                    String type = value.toString();
                    switch (type) {
                        case "Clock-in Correction":
                            c.setForeground(new Color(0, 102, 204));
                            break;
                        case "Clock-out Correction":
                            c.setForeground(new Color(0, 153, 51));
                            break;
                        case "Absent → Present":
                            c.setForeground(new Color(204, 102, 0));
                            break;
                        default:
                            c.setForeground(Color.BLACK);
                    }
                    ((JComponent)c).setToolTipText(type);
                } else {
                    c.setForeground(Color.BLACK);
                }

                return c;
            }
        });

        JScrollPane tableScroll = new JScrollPane(tableRequests);
        mainPanel.add(tableScroll, BorderLayout.CENTER);

        //--------BOTTOM PANEL (SLIDING REQUEST DETAILS)---- CLICK THE EMPLOYEE DETAILS AND THE DETAILS OF THE EMPLOYEE REQUEST WILL BE VISBLE--------
        initBottomPanel();
        mainPanel.add(bottomPanel, BorderLayout.SOUTH);

        // Table row selection triggers slide and updates details
        tableRequests.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                if (tableRequests.getSelectedRow() >= 0) {
                    updateRequestDetails();
                    slidePanel(true);
                } else {
                    slidePanel(false);
                }
            }
        });

        // Initialize details
        updateRequestDetails();
    }

    // ===== INIT SLIDING PANEL WITH CLOSE BUTTON =====
    private void initBottomPanel() {
        bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.setPreferredSize(new Dimension(getWidth(), 0)); // start collapsed
        bottomPanel.setBorder(new MatteBorder(1, 0, 0, 0, new Color(220, 220, 220)));
        bottomPanel.setBackground(Color.WHITE);

        // Top bar with close button
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setBackground(Color.WHITE);
        JButton btnClose = new JButton("×");
        btnClose.setFont(new Font("Segoe UI", Font.BOLD, 16));
        btnClose.setFocusPainted(false);
        btnClose.setBorder(null);
        btnClose.setContentAreaFilled(false);
        btnClose.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnClose.addActionListener(e -> slidePanel(false)); // collapse on click
        topBar.add(btnClose, BorderLayout.EAST);
        bottomPanel.add(topBar, BorderLayout.NORTH);

        txtDetails = new JTextPane();
        txtDetails.setEditable(false);
        txtDetails.setBackground(Color.WHITE);
        txtDetails.setBorder(new EmptyBorder(10, 10, 10, 10));
        JScrollPane detailsScroll = new JScrollPane(txtDetails);
        bottomPanel.add(detailsScroll, BorderLayout.CENTER);

        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 10));
        actionPanel.setBackground(Color.WHITE);
        JButton btnApprove = new JButton("Approve");
        stylizeButton(btnApprove);
        JButton btnReject = new JButton("Reject");
        stylizeButton(btnReject);
        actionPanel.add(btnApprove);
        actionPanel.add(btnReject);
        bottomPanel.add(actionPanel, BorderLayout.SOUTH);
    }

    // ===== SLIDE ANIMATION =====
    private void slidePanel(boolean expand) {
        if (slideTimer != null && slideTimer.isRunning()) slideTimer.stop();

        slideTimer = new Timer(5, null);
        slideTimer.addActionListener(e -> {
            if (expand) {
                if (panelHeight < MAX_HEIGHT) {
                    panelHeight += 10;
                    bottomPanel.setPreferredSize(new Dimension(getWidth(), panelHeight));
                    bottomPanel.revalidate();
                } else {
                    slideTimer.stop();
                }
            } else {
                if (panelHeight > 0) {
                    panelHeight -= 10;
                    bottomPanel.setPreferredSize(new Dimension(getWidth(), panelHeight));
                    bottomPanel.revalidate();
                } else {
                    slideTimer.stop();
                }
            }
        });
        slideTimer.start();
    }

    // ===== SIDEBAR BUTTON CREATION =====
    private JButton createSidebarButton(String text, boolean selected) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", selected ? Font.BOLD : Font.PLAIN, 15));
        btn.setFocusPainted(false);
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        btn.setBorder(null);
        btn.setOpaque(true);
        btn.setBackground(selected ? new Color(220, 230, 255) : new Color(248, 250, 255));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setForeground(Color.BLACK);

        // Hover effect------------------
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                if (!selected) btn.setBackground(new Color(230, 235, 255));
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                if (!selected) btn.setBackground(new Color(248, 250, 255));
            }
        });

        return btn;
    }

    // ------------- BUTTON STYLE ------------
    private void stylizeButton(JButton btn) {
        btn.setFocusPainted(false);
        btn.setBackground(new Color(240, 240, 240));
        btn.setBorder(new LineBorder(new Color(200, 200, 200)));
        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    }

    // ----------- UPDATE DETAILS PANEL --------------
    private void updateRequestDetails() {
        int selectedRow = tableRequests.getSelectedRow();
        if (selectedRow >= 0) {
            String employee = tableRequests.getValueAt(selectedRow, 0).toString();
            String date = tableRequests.getValueAt(selectedRow, 1).toString();
            String type = tableRequests.getValueAt(selectedRow, 2).toString();
            String status = tableRequests.getValueAt(selectedRow, 3).toString();

            String statusColor;
            switch (status) {
                case "Approved": statusColor = "green"; break;
                case "Rejected": statusColor = "red"; break;
                default: statusColor = "orange"; break;
            }

            String detailsHtml = "<html>" +
                "<b>Employee:</b> " + employee + "<br>" +
                "<b>Date:</b> " + date + "<br>" +
                "<b>Correction Type:</b> " + type + "<br>" +
                "<b>Status:</b> <span style='color:" + statusColor + "'>" + status + "</span><br><br>" +
                "<b>Original Time Record:</b> 08:00 - 17:00<br>" +
                "<b>Requested Correction:</b> 09:00 - 17:00<br>" +
                "<b>Justification:</b> Employee was late due to traffic.<br>" +
                "<b>Notes/Attachments:</b> None<br>" +
                "</html>";

            txtDetails.setContentType("text/html");
            txtDetails.setText(detailsHtml);

        } else {
            txtDetails.setContentType("text/html");
            txtDetails.setText("<html>Select a request from the table above to view details.<br><br>" +
                "All correction requests include:<br>" +
                "- Original Time Record<br>" +
                "- Requested New Time<br>" +
                "- Required Justification from Employee<br>" +
                "- Notes, Attachments (if any)</html>");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Manual_Attendance().setVisible(true));
    }
}
